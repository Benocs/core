/*
 * module to include the modules
 */
config_require(tsm-mib/snmpTsmStats)
config_require(tsm-mib/snmpTsmConfigurationUsePrefix)
config_add_mib(SNMP-TSM-MIB)
