/*
 * module to include the modules
 */

config_require(ip-mib/data_access/systemstats)
config_require(ip-mib/ipSystemStatsTable/ipSystemStatsTable)
config_require(ip-mib/ipSystemStatsTable/ipSystemStatsTable_interface)
config_require(ip-mib/ipSystemStatsTable/ipSystemStatsTable_data_access)
