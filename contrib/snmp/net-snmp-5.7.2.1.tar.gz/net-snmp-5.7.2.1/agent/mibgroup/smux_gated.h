/*
 * dummy module to load parts needed for smux/gated interaction 
 */
config_require(smux/snmp_ospf)
config_require(smux/snmp_rip2)
config_require(smux/snmp_bgp)
